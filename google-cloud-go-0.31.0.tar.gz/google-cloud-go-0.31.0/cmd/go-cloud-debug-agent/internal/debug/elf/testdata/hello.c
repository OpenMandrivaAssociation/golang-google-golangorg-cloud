#include <stdio.h>

void
main(int argc, char *argv[])
{
	printf("hello, world\n");
}
